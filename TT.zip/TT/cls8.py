class Contact:

    def __init__(self, name):
        self.name = name


class MailSender:

    def send_mail(self, text):
        print('Email to ->', self.email)
        print('Email Message ->', text)


class EmailableContact(Contact, MailSender):

    def __init__(self, name, email):
        super().__init__(name)
        self.email = email


e = EmailableContact('John Doe', 'jdoe@gmail.com')
e.send_mail('Hello Email')
