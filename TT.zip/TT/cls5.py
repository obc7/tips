class Car:
    def show(self):
        print(self.__class__.__name__)


class RaceCar(Car):
    pass


class F1Car(Car):

    def show(self):
        print('F1Car Override ', self.__class__.__name__)


class CityCar(Car):
    def show(self):
        print('CityCar Override ', self.__class__.__name__)


class TestCar(RaceCar, CityCar):
    pass


car = Car()
car.show()

race = RaceCar()
race.show()

f1car = F1Car()
f1car.show()

tstcar = TestCar()
tstcar.show()
