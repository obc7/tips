

def scope_func():
    value = 1
    print('scope_func:', value)


def main():
    value = 99
    scope_func()
    print('main:', value)


if __name__ == '__main__':
    main()
