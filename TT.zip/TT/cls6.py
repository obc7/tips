class A:

    def __init__(self, x):
        self.x = x

    def __str__(self):
        return str(self.x)


class B(A):

    def __init__(self, x, y):
        super().__init__(x)
        self.y = y

    def __str__(self):
        return '{0}, {1}'.format(self.x, self.y)


a = A(45)
print(a)

b = B(10, 20)
print(b)
