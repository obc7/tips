class PrivateTest:

    def __init__(self):
        self.__value = 42

    def __str__(self):
        return str(self.__value)


test = PrivateTest()
print(test)

print(test.__value)
