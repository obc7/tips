class MyFirstClass:
    pass


print(type(MyFirstClass))

first = MyFirstClass()
print(type(first))

print(type(first) == MyFirstClass)
