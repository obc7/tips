class Employee(object):
    cls_count = 0

    def __init__(self):
        Employee.cls_count += 1

    def show_count(self):
        print('Employee Count:', Employee.cls_count)


for _ in range(10):
    e = Employee()

worker = Employee()
worker.show_count()
