class Person:

    def __init__(self, person_id):
        self.__person_id = person_id

    def __str__(self):
        return 'Person Id {0}'.format(self.__person_id)


p1 = Person(1)
p2 = Person(2)
p3 = Person(3)


print(p1)
print(p2)
print(p3)
