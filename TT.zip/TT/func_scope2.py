def outer():
    value = 100

    def inner():
        value = 500
        print('inner:', value)

    inner()
    print('outer:', value)


def main():
    value = 99
    outer()
    print('main:', value)


if __name__ == '__main__':
    main()
