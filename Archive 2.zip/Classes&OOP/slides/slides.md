
class: center, middle

# Python
## Classes and Object Oriented Programming

---

## Procedure Programming

* Procedural programming: writing programs made of functions that perform specific tasks

* Procedures typically operate on data items that are separate from the procedures

* Data items commonly passed from one procedure to another

* Focus: to create procedures that operate on the program’s data

---

## Object-Oriented Programming

* Object-Oriented Programming: 
  * focuses on creating objects

* Object: entity that contains data and procedures/functions

  * Data is known as data attributes and procedures are known as methods

  * Methods perform operations on the data attributes

* Encapsulation: combining data and code into a single object

---

## Object-Oriented Programming (cont’d.)

![Alt text](images/image0.png "Optional title")

---

## Object-Oriented Programming

* Object-oriented programming has been immensely successful

* Smalltalk in the 70's, Simula in the mid-60's introduced **class** construct

* There is not a precise definition of what object-oriented means

> OOP to me means only messaging, local retention and protection and hiding of state-process, and extreme LateBinding of all things.
> 
>                                                    Alan Kay

---

## O-O Language Criteria

* Encapsulation

* Inheritance

* Polymorphism

* Composition

---

## Object-Oriented Programming

* Motivation of object-oriented programming is very simple

* All but the most trivial programs need some sort if structure

* Most straightforward way to do this is to put data and operations into some form of a container

* The idea of OO is to make these containers fully general, so they can contain operations as well as data, and that they are themselves values that can be stored in other containers

*  Such containers are called *Objects*

---

## Object-Oriented Programming

Alan Kay, the inventor of Smalltalk, remarked that in this way the simplest object has the same construction principle as a full computer: it combines data with operations under a formalized interface.  

So objects have a lot to do with language scalability: the same techniques apply to the construction of small as well as large programs.


---

## Object-Oriented Programming (cont’d.)

* Data hiding: object’s data attributes are hidden from code outside the object
  * Access restricted to the object’s methods

    * Protects from accidental corruption

    * Outside code does not need to know internal structure of the object

* Object reusability: the same object can be used in different programs 
  * Example: 3D image object can be used for architecture and game programming

---

## Object-Oriented Programming (cont’d.)

![Alt text](images/image1.png "Optional title")

---

## Nice Packages

* Objects address fundamental software development problems by combining data and behavior into a nice, complete package. 

* Objects are not just primitive data types, like integers and strings. 


---

## O-O Programming

* The fundamental advantage of O-O programming is that the data and the operations that manipulate the data are both contained in the object. 

* For example, when an object is transported across a network, the entire object, including the data and behavior, goes with it. 

---

## Object Data

* The data stored within an object represents the state of the object. 

* In O-O programming terminology, this data is called attributes. 

---

## Object Behaviors

* In O-O programming terminology behaviors are contained in methods, and you invoke a method by sending a message to it. 


---
## An Everyday Example of an Object

* Data attributes: define the state of an object
  * Example: clock object would have second, minute, and hour data attributes

* Public methods: allow external code to manipulate the object
  * Example: set_time, set_alarm_time

* Private methods: used for object’s inner workings

---

## What Exactly Is a Class?

* A class is a blueprint for an object. 

* When you instantiate an object, you use a class as the basis for how the object is built. 

---

## What Exactly Is a Class?

* An object cannot be instantiated without a class. 
 
* Classes can be thought of as the templates, or cookie cutters, for objects as seen in the next figure. 

---

## Higher Level Data Types?

* A class can be thought of as a sort of higher-level data type.  

* For example, just as you create an integer or a float:
```java
int x;
float y;
```

---

## Classes

* Class: code that specifies the data attributes and methods of a particular type of object
  * Similar to a blueprint of a house or a cookie cutter

* Instance: an object created from a class

  * Similar to a specific house built according to the blueprint or a specific cookie

  * There can be many instances of one class

---

## Classes (cont’d.)

![Alt text](images/image2.png "Optional title")

---

## Classes (cont’d.)

![Alt text](images/image3.png "Optional title")

---

## Classes (cont’d.)

![Alt text](images/image4.png "Optional title")

---

## Encapsulation

* One of the primary advantages of using objects is that the object need not reveal all its attributes and behaviors. 

* In good O-O design (at least what is generally accepted as good), an object should only reveal the interfaces needed to interact with it. 

---

## Encapsulation

* Details not pertinent to the use of the object should be hidden from other objects. 

* This is called encapsulation. 

---

## Interfaces

* Any behavior that the object provides must be invoked by a message sent using one of the provided interfaces. 

* The interface should completely describe how users of the class interact with the class.
 
* methods that are part of the interface are designated as public.

---

## Interfaces

* Interfaces do not normally include attributes only methods. 

* If a user needs access to an attribute, then a method is created to return the attribute. 

---

## Implementations

* Only the public attributes and methods are considered the interface. 

* The user should not see any part of the implementation interacting with an object solely through interfaces. 

* In previous example, for instance the Employee class, only the attributes were hidden. 

* Thus, the implementation can change and it will not affect the user's code.

---

 ## The Name of the Class

* The name of the class is important for several reasons. 

* To identify the class itself. 

* The name must be descriptive. 

* The choice of a name is important because it provides information about what the class does and how it interacts within larger systems.

---

 ## Comments

* Regardless of the syntax of the comments used, comments are vital to understanding the function of a class.

* While comments are vital to the documentation and maintenance of code, it is important not to over-comment.
 
---

## Attributes

* Attributes represent the state of the object because they store the information about the object.

* In many designs all attributes are private. 

* Keeping the interface design as minimal as possible. 

* The only way to access these attributes is through the method interfaces provided.

---

 ## Methods

* Methods represent the behavior of the object because they provide the functionality.

* Methods are defined by their signature and are used to invoke certain behaviors 

* One of the uses of methods is as accessor methods. 

---

# Class Definitions

* Class definition: set of statements that define a class’s methods and data attributes

  * Format: begin with 
```python
class Class_name:
```

    * Class names often start with uppercase letter

  * Method definition like any other python function definition

    * *self* parameter: required in every method in the class – references the specific object that the method is working on

---

## Class Definitions (cont’d.)

* Initializer method: automatically executed when an instance of the class is created

  * Initializes object’s data attributes and assigns self parameter to the object that was just created

  * Format: 
```python
  def __init__ (self):
```

  * Usually the first method in a class definition

---

## Class Definitions (cont’d.)

![Alt text](images/image5.png "Optional title")

---

## Class Definitions (cont’d.)

* To create a new instance of a class call the initializer method

  * Format: 
```python
  My_instance = Class_Name()
```

* To call any of the class methods using the created instance, use dot notation

  * Format: 
```python
  My_instance.method()
```

  * Because the self parameter references the specific instance of the object, the method will affect this instance

    * Reference to self is passed automatically

---

## Hiding Attributes and Storing Classes in Modules

* An object’s data attributes should be private
  * To make sure of this, place two underscores (__) in front of attribute name
    * example: *__current_minute*

* Classes can be stored in modules
  * Filename for module must end in .py

  * Module can be imported to programs that use the class

---

## The BankAccount Class – More About Classes

* Class methods can have multiple parameters in addition to self
  * For *__init__*, parameters needed to create an instance of the class 

    * Example: a BankAccount object is created with a  balance
    * When called, the initializer method receives a value to be assigned to a 
 *__balance* attribute

* For other methods, parameters needed to perform required task
  * Example: deposit method amount to be deposited

---

## The __str__ method

* Object’s state: the values of the object’s attribute at a given moment
*__str__* method: displays the object’s state

  * Automatically called when the object is passed as an argument to the print function

  * Automatically called when the object is passed as an argument to the str function

---

## Working With Instances

* Instance attribute: belongs to a specific instance of a class
  * Created when a method uses the self parameter to create an attribute

* If many instances of a class are created, each would have its own set of attributes

---

![Alt text](images/image6.png "Optional title")
![Alt text](images/image7.png "Optional title")

---

## Accessor and Mutator Methods

* Typically, all of a class’s data attributes are private and provide methods to access and change them

* Accessor methods: return a value from a class’s attribute without changing it
Safe way for code outside the class to retrieve the value of attributes

* Mutator methods: store or change the value of a data attribute

---

## Passing Objects as Arguments

* Methods and functions often need to accept objects as arguments
  * When you pass an object as an argument, you are actually passing a reference to the object

* The receiving method or function has access to the actual object
  * Methods of the object can be called within the receiving function or method, and data attributes may be changed using mutator methods

---

## Techniques for Designing Classes

* UML diagram: standard diagrams for graphically depicting object-oriented systems
  * Stands for Unified Modeling Language

* General layout: box divided into three sections:
  * Top section: name of the class

  * Middle section: list of data attributes

  * Bottom section: list of class methods

---

![Alt text](images/image8.png "Optional title")

---

##  How to Think In Terms of Objects

* Three important things you can do to develop a good sense of the OO thought process are:

  * Knowing the difference between the interface and implementation

  * Thinking more abstractly

  * Giving the user the minimal interface possible

---

 ## Interface vs. Implementation

* When designing a class: 

* What the user needs to know and what the user does not need to know are of vital importance. 

* The data hiding mechanism inherent with encapsulation is the means by which nonessential data is hidden from the user.

---

 ## The Interface

* The services presented to an end user compose the interface. 

* In the best case, only the services the end user needs are presented.

* As a general rule, the interface to a class should contain only what the user needs to know. 

---

 ## The Implementation

* The implementation details are hidden from the user. 

* A change to the implementation should not require a change to the user’s code

* If the interface does not change, the user does not care whether or not the implementation is changed.

---

 ## Abstract Thinking

* One of the main advantages of OO programming is that classes can be reused. 

* Reusable classes tend to have interfaces that are more abstract than concrete

* Concrete interfaces tend to be very specific. 

* Abstract interfaces are more general. 
 
---

## The Minimal User Interface

* Give the users only what they absolutely need.

* It is better to have to add interfaces because users really need it than to give the users more interfaces than they need.

* Public interfaces define what the users can access.

* It is vital to design classes from a user’s perspective and not from an information systems viewpoint.

* Make sure when you are designing a class that you go over the requirements and the design with the people who will actually use it—not just developers.

---

 ## Determining the Users

* Who are the users?

* The first impulse is to say the customers.

* This is only about half right. 

* Although the customers are certainly users, the developers must be a partner with the users. 

* In short, users can have unrealistic expectations.

---

 ## Object Behavior

* After the users are identified:

* You must determine the behaviors of the objects.

* From the viewpoint of all the users, begin identifying the purpose of each object and what it must do to perform properly. 

* Note that many of the initial choices will not survive the final cut of the public interface.

---

 ## Environmental Constraints

* Environmental constraints are almost always a factor. 

* Computer hardware might limit software functionality. 

* A system might not be connected to a network, or a company might use a specific type of printer.

---

 ## The Public Interfaces

* Think about how the object is used and not how it is built. 

* You might discover that the object needs more interfaces

Nailing down the final interface is an iterative process
It is often recommended that each interface model only one behavior.

---

 ## Indentifying The Implementation

* Technically, anything that is not a public interface can be considered the implementation. 

* This means that the user will never see any of the methods that are considered part of the implementation.

* Including the method’s signature (which includes the name of the method and the parameter list), as well as the actual code inside the method.

---

## Finding the Classes in a Problem

* When developing object oriented program, first goal is to identify classes
  * Typically involves identifying the real-world objects that are in the problem

  * Technique for identifying classes:

    * Get written description of the problem domain

    * Identify all nouns in the description, each of which is a potential class

    * Refine the list to include only classes that are relevant to the problem

---

## Finding the Classes in a Problem (cont’d.)

### Get written description of the problem domain

  * May be written by you or by an expert

  * Should include any or all of the following:

    * Physical objects simulated by the program

    * The role played by a person 

    * The result of a business event

    * Recordkeeping items

---

## Finding the Classes in a Problem (cont’d.)

### Identify all nouns in the description, each of which is a potential class

  * Should include noun phrases and pronouns

  * Some nouns may appear twice

---

## Finding the Classes in a Problem (cont’d.)

### Refine the list to include only classes that are relevant to the problem

  * Remove nouns that mean the same thing

  * Remove nouns that represent items that the program does not need to be concerned with

  * Remove nouns that represent objects, not classes

  * Remove nouns that represent simple values that can be assigned to a variable

---

## Identifying a Class’s Responsibilities

* A classes responsibilities are:

  * The things the class is responsible for knowing
    * Identifying these helps identify the class’s data attributes

  * The actions the class is responsible for doing
    * Identifying these helps identify the class’s methods

* To find out a class’s responsibilities look at the problem domain
  * Deduce required information and actions

