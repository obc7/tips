

class MyFirstClass:
    pass


first = MyFirstClass()
print(first)