

class MyFirstClass:
    pass

