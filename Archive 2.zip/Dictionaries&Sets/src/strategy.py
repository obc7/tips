import json
from urllib.request import urlopen


def load_content(url):
    response = urlopen(url)
    contents = response.read()
    return contents.decode('utf8')


def retrieve_quote():
    data = load_content('http://www.iheartquotes.com/api/v1/random')
    print('Quote:')
    print(data)


def retrieve_youtube_popular():
    text = load_content('https://gdata.youtube.com/feeds/api/standardfeeds/US/most_popular?alt=json')
    print('Most Popular on YouTube:')
    print(text)
    json_data = json.loads(text)

    for video in json_data['feed']['entry'][0:6]:
        print('\t', video['title']['$t'])


def main():
    retrieve_quote()
    print()
    retrieve_youtube_popular()


# Call the main function.
main()
