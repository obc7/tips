

def main():
    d1 = {}
    print('dict ->', d1)

    d2 = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    print('dict ->', d2)

    s = 'abcdef'
    t = [4, 5, 6, 10, 15, 20]

    d3 = dict(zip(s, t))
    print('dict ->', d3)

# Call the main function.
main()
