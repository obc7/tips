

class First:
    
    def __init__(self):
        print('First.__init__')


class Second(First):
    
    def __init__(self):
        print('Second.__init__')


class Third(First):

    def __init__(self):
        First.__init__(self)
        print('Third.__init__')


class Fourth(Second, First):

    def __init__(self):
        Second.__init__(self)
        print('Fourth.__init__')


second = Second()
third = Third()
fourth = Fourth()