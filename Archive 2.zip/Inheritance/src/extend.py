

class BaseClass:

    def __init__(self):
        print('BaseClass.__init__')

    def method(self):
        print('BaseClass.method()')


class Extender(BaseClass):

    def method(self):
        BaseClass.method(self)
        print('Extender.method()')


extender = Extender()
extender.method()