
class: center, middle

# Python
## Inheritance

---

## Introduction to Inheritance

* In the real world, many objects are a specialized version of more general  objects

* Example: grasshoppers and bees are specialized types of insect

* In addition to the general insect characteristics, they have unique characteristics:

  * Grasshoppers can jump
  * Bees can sting, make honey, and build hives

---

## Introduction to Inheritance (cont’d.)

![Alt text](images/image0.png "Optional title")

---

## Inheritance

* Inheritance allows a class to inherit the attributes and methods of another class. 

  * This allows you to create brand new classes by abstracting out common attributes and behaviors. 

---

## Mammal Hierarchy

![Alt text](images/image2.png "Optional title")

---

## Superclasses and Subclasses

* The superclass, or parent class, contains all the attributes and behaviors that are common to classes that inherit from it.

---

## Mammal Hierarchy

![Alt text](images/image3.png "Optional title")

---

## Inheritance and the “Is a” Relationship

* “Is a” relationship: exists when one object is a specialized version of another object

* Specialized object has all the characteristics of the general object plus unique characteristics

* Example: 
  * Rectangle is a shape
  * Daisy is a flower

---

## Is-a Relationships

* In the Shape example, Circle, Square, and Star all inherit directly from Shape. 

  * This relationship is often referred to as an is-a relationship because a circle is a shape. 

---

## Inheritance and the “Is a” Relationship (cont’d.)

* Inheritance: used to create an “is a” relationship between classes 

* Superclass (base class): a general class 

* Subclass (derived class): a specialized class

  * An extended version of the superclass
  
    * Inherits attributes and methods of the superclass
    
    * New attributes and methods can be added

---

## Inheritance and the “Is a” Relationship (cont’d.)

* For example, need to create classes for cars, pickup trucks, and SUVs
All are automobiles

* Have a make, year model, mileage, and price 

* This can be the attributes for the base class

  * In addition:

    * Car has a number of doors 

    * Pickup truck has a drive type

    * SUV has a passenger capacity

---

## Inheritance and the “Is a” Relationship (cont’d.)

* In a class definition for a subclass:

* To indicate inheritance, the superclass name is placed in parentheses after subclass name

  * Example: 
  ```python
  class Car(Automobile):
  ```

    * The initializer method of a subclass calls the initializer method of the superclass and then initializes the unique data attributes

    * Add method definitions for unique methods

---

## Inheritance in UML Diagrams

* In UML diagram, show inheritance by drawing a line with an open arrowhead from subclass to superclass

---

![Alt text](images/image1.png "Optional title")

---

## Multiple Inheritance

* Multiple inheritance allows a class to inherit from more than one class.

* Multiple inheritance can significantly increase the complexity of a system, 
Java, .NET, and Objective-C do not support multiple inheritance (C++ does).

* In some ways interfaces compensates for this.

---

## Polymorphism

* Polymorphism literally means many shapes. 

    ![Alt text](images/image4.png "Optional title")

---

## Polymorphism

* The Shape object cannot draw a shape, it is too abstract (in fact, the Draw() method in Shape contains no implementation). 

  * You must specify a concrete shape. 

  * To do this, you provide the actual implementation in Circle. 

---

## Polymorphism

* In short, each class is able to respond differently to the same Draw method and draw itself. 

  * This is what is meant by polymorphism.

---

## Polymorphism

* When a method is defined as abstract, a subclass must provide the implementation for this method. 

  * In this case, Shape is requiring subclasses to provide a getArea() implementation. 

---

## Polymorphism

  * If a subclass inherits an abstract method from a superclass, it must provide a concrete implementation of that method, or else it will be an abstract class itself (see the following figure for a UML diagram).

---

## Shape UML Diagram

![Alt text](images/image5.png "Optional title")

---

## Polymorphism

* Polymorphism: an object’s ability to take different forms

* Essential ingredients of polymorphic behavior:

* Ability to define a method in a superclass and override it in a subclass

* Subclass defines method with the same name

* Ability to call the correct version of overridden method depending on the type of object that called for it

---

## Polymorphism (cont’d.)

* In previous inheritance examples showed how to override the **`__init__`** method

* Called superclass **`__init__`** method and then added onto that

* The same can be done for any other method

* The method can call the superclass equivalent and add to it, or do something completely different

---

## The isinstance Function

* Polymorphism provides great flexibility when designing programs

* **`AttributeError`** exception: raised when a method is receives an object which is not an instance of the right class

* **`isinstance`** function: determines whether object is an instance of a class

* Format: 
```python
isinstance(object, class)
```

---

## Composition

* It is natural to think of objects as containing other objects. 

  * A television set contains a tuner and video display. 

---

## Composition

* A computer contains video cards, keyboards, and drives. 

  * Although the computer can be considered an object unto itself, the drive is also considered a valid object. 

---

## Composition

* In fact, you could open up the computer and remove the drive and hold it in your hand. 

  * Both the computer and the drive are considered objects. It is just that the computer contains other objects such as drives.
  
  * In this way, objects are often built, or composed, from other objects: This is composition.

---

## Has-a Relationships

* While an inheritance relationship is considered an Is-a relationship for reasons already discussed, a composition relationship is termed a Has-a relationship. 

---

## Has-a Relationships

* Using the example in the previous section, a television Has-a a tuner and Has-a video display. 

* A television is obviously not a tuner, so there is no inheritance relationship. 

---

## Has-a Relationships

* In the same vein, a computer Has-a video card, Has-a keyboard, and Has-a disk drive. 

* The topics of inheritance, composition and how they relate to each other is covered in great detail later in the course.

---

## Reusing Objects

* Perhaps the primary reason that inheritance and composition exist is object reuse.

  * Inheritance represents the is-a relationship.
    
    * For example, a dog is a mammal.

  * Composition represents a has-a relationship.

    * For example, a car has a(n) engine.

---

## Inheritance

* Inheritance was defined as a system in which child classes inherit attributes and behaviors from a parent class.

* If you can say that Class B is a Class A, then this relationship is a good candidate for inheritance.
 
---

## Generalization and Specialization

* Consider an object model of a Dog class hierarchy. 

* Factored out some of the commonality between various breeds of dogs is called generalization-specialization.

* The idea is that as you make your way down the inheritance tree, things get more specific.
 
---

## Design Decisions

* Factoring out as much commonality as possible is great. 

* Sometimes it really is too much of a good thing.

* Although factoring out as much commonality as possible might represent real life as closely as possible, it might not represent your model as closely as possible.
 
---

## Model Complexity

* Adding classes can make things so complex that it makes the model untenable. 

* In larger systems, when these kinds of decisions are made over and over, the complexity quickly adds up.

---

## Making Design Decisions with the Future in Mind

* If you are modeling a system for a veterinarian, you may not currently treat cats.

  * Although you might not treat cats now, sometime in the future you might want to do so. 

  * If you do not design for the possibility of treating cats now, it will be much more expensive to change the system later to include them.
 
---

## Composition

* It is natural to think of objects as containing other objects. 

  * A television set contains a tuner and video display. 

  * A computer contains video cards, keyboards, and drives. 

  * The computer can be considered an object unto itself, and a flash drive is also considered a valid object.

---
 
## Model Complexity

* As with inheritance, using too much composition can also lead to more complexity. 

  * A fine line exists between creating an object model that contains enough granularity to be sufficiently expressive and a model that is so granular that it is difficult to understand and maintain.
 
---

## Why Encapsulation Is Fundamental to OO

* Whenever the interface/implementation paradigm is covered, we are talking about encapsulation. 

  * The basic question is what in a class should be exposed and what should not be exposed. 

  * This encapsulation pertains equally to data and behavior.
 
---

## How Inheritance Weakens Encapsulation

* Inheritance connotes strong encapsulation with other classes but weak encapsulation between a superclass and its subclasses.

  * The problem is that if you inherit an implementation from a superclass and then change that implementation, the change from the superclass ripples through the class hierarchy.
 
    * This rippling effect potentially affects all the subclasses.  
 
---

## Object Responsibility

* The premise of polymorphism is that you can send messages to various objects, and they will respond according to their object’s type.

* The important point regarding polymorphism is that an object being responsible for itself.

