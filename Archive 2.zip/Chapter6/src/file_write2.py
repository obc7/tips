

# This program writes three lines of data
# to a file.
def main():

    data_list = [
        'John Locke',
        'David Hume',
        'Edmund Burke',
        'Friedeich Nietzsche',
        'Plato',
        'Socrates',
        'Aristotle',
        'Mazen Asfour',
        'Sri Aurobindo',
        'Avicenna',
        'Karl Marx',
        'Lao Tzu',
        'Peter Unger'
    ]

    # Open a file named philosophers.txt.
    with open('philosophers.txt', 'w') as out:

        # Write the names of philosphers
        # to the file.
        out.writelines('%s\n' % item for item in data_list)

# Call the main function.
main()
