# This program divides a number by another number.


def main():
    # Get two numbers.
    num1 = int(input('Enter a number: '))
    num2 = int(input('Enter another number: '))

    # Divide num1 by num2 and display the result.
    try:
        result = num1 / num2
    except ZeroDivisionError as error:
        print(error)
    else:
        print(num1, 'divided by', num2, 'is', result)

# Call the main function.
main()
