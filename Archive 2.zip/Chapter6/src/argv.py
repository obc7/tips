import sys

print('The argument count is %i' % (len(sys.argv)-1))

for arg in sys.argv:
    print(arg)



