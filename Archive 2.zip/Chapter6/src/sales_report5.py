# This program displays the total of the
# amounts in the sales_data.txt file.


def main():
    # Initialize an accumulator.
    total = 0.0

    # Open the sales_data.txt file.
    with open('sales_data.txt', 'r') as infile:
        try:
            # Read the values from the file and
            # accumulate them.
            for line in infile:
                amount = float(line)
                total += amount

        except Exception as err:
            print(err)
        else:
            # Print the total.
            print(format(total, ',.2f'))

# Call the main function.
main()
