

# This program reads and displays the contents
# of the philosophers.txt file.
def main():
    # Open a file named philosophers.txt.
    with open('philosophers.txt', 'r') as infile:

        # Read the file's contents.
        file_contents = infile.read()

        # Print the data that was read into
        # memory.
        print(file_contents)

# Call the main function.
main()
