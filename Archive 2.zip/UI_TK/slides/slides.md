
class: center, middle

# Python
## GUI Programming

---

## Graphical User Interfaces

* User Interface: the part of the computer with which the user interacts

* Command line interface: displays a prompt and the user types a command that is then executed

* Graphical User Interface (GUI): allows users to interact with a program through graphical elements on the screen

---

## Graphical User Interfaces (cont’d.)
![Alt text](images/image0.png "Optional title")

---

## Graphical User Interfaces (cont’d.)

* Dialog boxes: small windows that display information and allow the user to perform actions

    * Responsible for most of the interaction through GUI
    
    * User interacts with graphical elements such as icons, buttons, and slider bars

---

## Dialog Box
![Alt text](images/image1.png "Optional title")

---

## GUI Programs Are Event-Driven

* In text-based environments, programs determine the order in which things happen
 
    * The user can only enter data in the order requested by the program

    * GUI environment is event-driven

        - The user determines the order in which things happen

        - User causes events to take place and the program responds to the events

---

## Using the tkinter Module

* No GUI programming features built into Python

* tkinter module: allows you to create simple GUI programs
Comes with Python

* Widget: graphical element that the user can interact with or view

    - Presented by a GUI program

---

## Using the tkinter Module (cont’d.)

* Programs that use tkinter do not always run reliably under IDLE

    * For best results run them from operating system command prompt

    * Most programmers take an object-oriented approach when writing GUI programs

        - **```__init__```** method builds the GUI
    
        - When an instance is created the GUI appears on the screen

---

## Display Text with Label Widgets

* Label widget: displays a single line of text in a window

    * Made by creating an instance of tkinter module’s Label class

    * Format: 
```python 
tkinter.Label(self.main_window, text = 'my text')
```

        - First argument references the root widget, second argument shows text that should appear in label

---

## Display Text with Label Widgets (cont’d.)

* pack method: determines where a widget should be positioned and makes it visible when the main window is displayed

    * Called for each widget in a window

    * Receives an argument to specify positioning

        - Positioning depends on the order in which widgets were added to the main window

        - Valid arguments: side='top', side='left', side='right'

---

## Display Text with Label Widgets (cont’d.)
![Alt text](images/image2.png "Optional title")
![Alt text](images/image3.png "Optional title")
![Alt text](images/image4.png "Optional title")

---

## Organizing Widgets with Frames

* Frame widget: container that holds other widgets

    * Useful for organizing and arranging groups of widgets in a window

        - The contained widgets are added to the frame widget which contains them

        - Example:
```python
  tkinter.Label(self.top_frame, text = 'hi')
```

---

## Organizing Widgets with Frames (cont’d.)

![Alt text](images/image5.png "Optional title")

---

## Button Widgets and Info Dialog Boxes

* Button widget: widget that the user can click to cause an action to take place

    * When creating a button can specify:

        - Text to appear on the face of the button
        - A callback function

    * Callback function: function or method that executes when the user clicks the button
        - Also known as an event handler

---

## Button Widgets and Info Dialog Boxes (cont’d.)

* Info dialog box: a dialog box that shows information to the user

    * Format for creating an info dialog box:

        - Import tkinter.messagebox module
```pytohn
tkinter.messagebox.showinfo(title, message)
```

        - title is displayed in dialog box’s title bar
        - message is an informational string displayed in the main part of the dialog box

---

## Button Widgets and Info Dialog Boxes (cont’d.)
![Alt text](images/image6.png "Optional title")

---

## Creating a Quit Button

* Quit button: closes the program when the user clicks it

* To create a quit button in Python:

    * Create a Button widget

    * Set the root widget’s destroy method as the callback function

        - When the user clicks the button the destroy method is called and the program ends

---

## Getting Input with the Entry Widget

* Entry widget: rectangular area that the user can type text into

    * Used to gather input in a GUI program

    * Typically followed by a button for submitting the data

        - The button’s callback function retrieves the data from the Entry widgets and processes it

    * Entry widget’s get method: used to retrieve the data from an Entry widget
    
        - Returns a string

---

## Getting Input with the Entry Widget (cont’d.)
![Alt text](images/image7.png "Optional title")

---

## Using Labels as Output Fields

* Can use Label widgets to dynamically display output

    * Used to replace info dialog box 

    * Create empty Label widget in main window, and write code that displays desired data in the label when a button is clicked

---

## Using Labels as Output Fields (cont’d.)

* StringVar class: tkinter module class that can be used along with Label widget to display data

    * Create StringVar object and then create Label widget and associate it with the StringVar object

    * Subsequently, any value stored in the StringVar object with automatically be displayed in the Label widget

---

## Using Labels as Output Fields (cont’d.)
![Alt text](images/image8.png "Optional title")

---

## Radio Buttons and Check Buttons

* Radio button: small circle that appears filled when it is selected and appears empty when it is deselected

    * Useful when you want the user to select one choice from several possible options

* Radiobutton widgets: created using tkinter module’s Radiobutton class

    * Radiobutton widgets are mutually exclusive

        - Only one radio button in a container may be selected at any given time

---

## Radio Buttons and Check Buttons (cont’d)

* IntVar class: a tkinter module class that can be used along with Radiobutton widgets
    
    * Steps for use: 

        - Associate group of Radiobutton widgets with the same IntVar object

        - Assign unique integer to each Radiobutton

        - When a Radiobutton widgets is selected, its unique integer is stored in the IntVar object
    
    * Can be used to select a default radio button

---

## Using Callback Functions with Radiobuttons

* You can specify a callback function with Radiobutton widgets

    * Provide an argument command=self.my_method when creating the Radiobutton widget

    * The command will execute immediately when the radio button is selected

    * Replaces the need for a user to click OK or submit before determining which Radiobutton is selected

---

## Check Buttons

* Check button: small box with a label appearing next to it; check mark indicates when it is selected

    * User is allowed to select any or all of the check buttons that are displayed in a group
        
        - Not mutually exclusive

* Checkbutton widgets: created using tkinter module’s Checkbutton class

    * Associate different IntVar object with each Checkbutton widget
