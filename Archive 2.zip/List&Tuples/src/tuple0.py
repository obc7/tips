def main():
    t = 'a', 'b', 'c', 'd', 'e', 'f'
    print('tuple ->', t)

    t = ('a', 'b', 'c', 'd', 'e', 'f')
    print('tuple ->', t)

    print('data =>', t[0])
    print('data =>', t[1:3])


# Call the main function.
main()

