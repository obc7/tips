def main():
    s = 'abc'
    t = [0, 1, 2]
    z = ['test', 'junk', 'dog']
    d = list(zip(s, t, z))

    print('data ->', d)

    for letter, number, _ in d:
        print(number, letter)

# Call the main function.
main()
