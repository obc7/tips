def main():
    list1 = [10, 20, 30, 40]
    print(list1)

    list2 = ['horse', 'dog', 'cow']
    print(list2)

    list3 = ['spam', 2.0, 5, [10, 20]]
    print(list3)

# Call the main function.
main()
