
number = int(input('Enter your a number: '))

if number >= 20 and number <= 40:
    print('You number is within the valid range...')
else:
    print('bad number')
