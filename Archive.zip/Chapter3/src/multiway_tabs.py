x = 'killer rabbit'

if x == 'roger':
	print('where is Jessica?')
elif x == 'bugs':
	print('''What's up doc?''')
else:
	print('Run away! Run away!')
