
number = int(input('Enter your a number: '))

if number < 20 or number > 40:
    print('You number is outside the range...')
