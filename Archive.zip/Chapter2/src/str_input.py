firstName = input('Enter your first name: ')
lastName = input('Enter your last name: ')

print('Hello', firstName, lastName)