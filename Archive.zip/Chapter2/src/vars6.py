firstName = 'John'
lastName = 'Doe'

print(firstName, lastName)