num1 = float(input('Enter first number: '))
num2 = float(input('Enter second number: '))
num3 = float(input('Enter third number: '))

bad_average = num1 + num2 + num3 / 3.0
average = (num1 + num2 + num3) / 3.0

print('Bad average', bad_average)
print('Average', average)
