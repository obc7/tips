room = 503 
print(room, type(room))

dollars = 4.95
print(dollars, type(dollars))