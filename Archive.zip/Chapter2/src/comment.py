
# This is a python comment

# Printing out some data
print('Ricky Bobby')
print('3366  Speedway Blvd')
print('Talladega, AL 35160')


