print("""I'm reading "Hamlet" tonight.""")

print('''I'm reading "Hamlet" tonight.''')

print('''One
	Two
	Three
	Four''')