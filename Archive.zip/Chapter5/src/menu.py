

def menu(wine, entree, dessert):
    print('wine:', wine)
    print('entree:', entree)
    print('dessert:', dessert)


def menu2(wine, entree, dessert='ice cream'):
    print('wine:', wine)
    print('entree:', entree)
    print('dessert:', dessert)


menu('white', 'salmon', 'lemon cake')
print('--' * 10)
menu('red', entree='beef', dessert='apple pie')
print('--' * 10)
menu2(wine='house', entree='chicken')

