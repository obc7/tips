
def changer(a, b): # Arguments assigned references to objects
    a = 2 # Changes local name's value only
    b[0] = 'spam' # Changes shared object in place


X = 1
L = [1, 2] # Caller:

changer(X, L) # Pass immutable and mutable objects
print(X, L)  # X is unchanged, L is different! (1, ['spam', 2])

