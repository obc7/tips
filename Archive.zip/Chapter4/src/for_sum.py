# This program demonstrates a simple for loop which
# computes a sum

def main():
    sum = 0
    for x in [1, 2, 3, 4]:
        sum = sum + x

    print(sum)

# Call the main function.
main()

