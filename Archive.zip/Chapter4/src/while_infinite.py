# This program demonstrates a simple infinite while loop

while True:
    print('Type Ctrl-C to stop me...')
