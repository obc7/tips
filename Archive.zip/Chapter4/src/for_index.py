# This program demonstrates a simple for loop with
# value and index

#this makes print work like python 3.+
from __future__ import print_function

def main():
    print('I will display the numbers 1 through 5.')
    for i, num in enumerate([1, 2, 3, 4, 5]):
        print(i, num)

# Call the main function.
main()
