bmi = 19

if bmi > 18.5 and bmi < 25:
  print('optimal')