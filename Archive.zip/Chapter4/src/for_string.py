# This program demonstrates a simple for loop over
# a string

def main():
    text = 'lumberjack'
    for c in text:
        print c,



# Call the main function.
main()

