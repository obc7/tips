print range(5)

print range(2,5)

print range(0, 10, 2)

print range(10, 0, -1)