
L = [lambda x: x ** 2, # Inline function definition
     lambda x: x ** 3,
     lambda x: x ** 4]


# A list of three callable functions
for f in L:
    print(f(2))  # Prints 4, 8, 16

print()
print('--' * 14)
print(L[0](3)) # Prints 9
print('--' * 8)
print(L)