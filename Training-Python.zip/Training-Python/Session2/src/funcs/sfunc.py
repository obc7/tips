

def inc(x): return x + 10 # Function to be run


counters = [1, 2, 3, 4]

updated = []
for x in counters:
    updated.append(x + 10) # Add 10 to each item >>> updated [11, 12, 13, 14]

print(updated)

print(list(map(inc, counters))) # Collect results [11, 12, 13, 14]

print(list(map((lambda x: x + 10), counters))) # Function expression [4, 5, 6, 7]

from functools import reduce
# Import in 3.X, not in 2.X
print(reduce((lambda x, y: x + y), [1, 2, 3, 4]))  # 10
print(reduce((lambda x, y: x * y), [1, 2, 3, 4]))  # 24

