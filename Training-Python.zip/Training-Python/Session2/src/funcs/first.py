

def answer():
    print(42)


def run_something(func):
    func()


run_something(answer)
