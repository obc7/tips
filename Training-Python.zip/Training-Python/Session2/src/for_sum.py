# This program demonstrates a simple for loop which
# computes a sum


def main():

    sum_up = 0
    for x in [1, 2, 3, 4]:
        sum_up += x

    print(sum_up)


# Call the main function.
main()

