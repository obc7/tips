# This program reads numbers from a file into a list.
def main():
    file = open('numberlist.txt', 'r')

    for line in file:
        print(line, end='')

    file.close()


# Call the main function.
main()
