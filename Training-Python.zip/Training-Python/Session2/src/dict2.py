

def main():
    d = {'spam': 2, 'ham': 1, 'eggs': 3}

    print('item', d['spam'])
    print('dict() len', len(d))
    print('dict() contains ham', 'ham' in d)
    print('keys', d.keys())
    print('values', d.values())

    d['ham'] = ['grill', 'bake', 'fry']

    print('dict()', d)

    del d['eggs']
    print('dict()', d)

    d['brunch'] = 'Bacon'
    print(d)


# Call the main function.
main()
