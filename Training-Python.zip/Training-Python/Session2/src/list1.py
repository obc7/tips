def main():
    cheeses = ['Cheddar', 'Blue', 'Gouda']

    print(cheeses[0])

    numbers = [17, 123]
    numbers[1] = 5
    print(numbers)

    print('Gouda' in cheeses)
    print('Sharp Cheddar' in cheeses)


# Call the main function.
main()
