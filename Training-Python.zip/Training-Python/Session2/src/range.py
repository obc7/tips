print(range(5))

print(range(2,5))

print(range(0, 10, 2))

print(range(10, 0, -1))

for r in range(5):
    print(r)

print('-' * 80)

for r in range(2, 5):
    print(r)

print('-' * 80)

for r in range(0, 10, 2):
    print(r)

print('-' * 80)

for r in range(10, 0, -1):
    print(r)
