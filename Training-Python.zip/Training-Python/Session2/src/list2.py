def main():
    a = [1, 2, 3]
    b = [5, 6, 7]

    c = a + b
    print(c)

    print('-' * 80)

    d = [1, 2, 3] * 3
    print(d)

# Call the main function.
main()

