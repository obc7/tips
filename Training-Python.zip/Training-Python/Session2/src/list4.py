def main():
    t = ['a', 'b', 'c', 'd', 'e', 'f']

    x = t.pop(1)
    print('data pop ->', t, x)

    t = ['a', 'b', 'c', 'd', 'e', 'f']
    del t[1]
    print('data del ->', t)

    t = ['a', 'b', 'c', 'd', 'e', 'f']
    t.remove('b')
    print('data remove ->', t)


# Call the main function.
main()

