# This program demonstrates a simple count while loop


def main():
    a=0; b=10
    while a < b:
        print(a)
        a += 1  # a = a + 1

    print('We are done...')


# Call the main function.
main()
