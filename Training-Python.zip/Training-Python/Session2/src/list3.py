def main():
    t = ['a', 'b', 'c', 'd', 'e', 'f']
    print('list of data', t)

    print('slice 1:3 ->', t[1:3])

    print('slice :4 ->', t[:4])
    print('slice 3: ->', t[3:])

    print('slice : ->', t[:])

    t[1:3] = ['x', 'y']
    print('slice update', t)


# Call the main function.
main()

