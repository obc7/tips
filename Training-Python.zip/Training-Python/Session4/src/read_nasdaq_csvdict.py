# ftp://ftp.nasdaqtrader.com/symboldirectory
import csv

def main():

    # Open a file for reading.
    with open(r'nasdaqlisted.txt', 'r') as file:
        csvfile = csv.DictReader(file, delimiter='|')

        print('Column Names:')
        print(csvfile.fieldnames)
        print()

        print('Data:')
        for row in csvfile:
            if row['Test Issue'] == 'N':
                print(row['Symbol'], row['Security Name'])


# Call the main function.
main()
