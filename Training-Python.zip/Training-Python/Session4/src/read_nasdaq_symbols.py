# ftp://ftp.nasdaqtrader.com/symboldirectory
import csv
import urllib.request


def main():
    symbols = []
    # Open a file for reading.
    with open('symbols.csv', 'r') as file:
        csvfile = csv.DictReader(file)

        print('Column Names:')
        print(csvfile.fieldnames)
        print()

        print('Data:')
        for row in csvfile:
            symbols.append(row['symbol'])

    print(symbols)

    # s = symbol, n = name, d1 = Last Trade Date, l1 = Last Trade (Price Only)
    url_string = 'http://finance.yahoo.com/d/quotes.csv?s={0}&f=snd1l1"'.format(symbols[0])
    csvdata = urllib.request.urlopen(url_string).readlines()
    # print(str(csvdata[0], 'utf-8'))
    print(csvdata)



# Call the main function.
main()
