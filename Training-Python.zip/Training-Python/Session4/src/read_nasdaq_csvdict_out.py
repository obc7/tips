# ftp://ftp.nasdaqtrader.com/symboldirectory
import csv

def main():

    data = []
    # Open a file for reading.
    with open('nasdaqlisted.txt', 'r') as file:
        csvfile = csv.DictReader(file, delimiter='|')

        print('Column Names:')
        print(csvfile.fieldnames)
        print()

        print('Data:')
        for row in csvfile:
            if row['Test Issue'] == 'N':
                data.append((row['Symbol'], row['Security Name']))

    print(data)

    with open('symbols.csv', 'w') as file:
        headers = ['symbol', 'symbol name']
        writer = csv.DictWriter(file, fieldnames=headers)

        writer.writeheader()
        for symbol, name in data:
            writer.writerow({'symbol': symbol, 'symbol name': name})

# Call the main function.
main()
