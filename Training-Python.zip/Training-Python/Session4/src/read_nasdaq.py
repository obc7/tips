# ftp://ftp.nasdaqtrader.com/symboldirectory


def main():

    # Open a file for reading.
    with open(r'nasdaqlisted.txt', 'r') as file:
        for line in file:
            print(line, end='')


# Call the main function.
main()
