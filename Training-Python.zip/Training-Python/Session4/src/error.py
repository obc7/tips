def this_fails():
    x = 0

    try:
        x = 1 / 0
    except ZeroDivisionError as err:
        print('Handling run-time error:', err)


this_fails()