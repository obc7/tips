# ftp://ftp.nasdaqtrader.com/symboldirectory
import csv

def main():

    # Open a file for reading.
    with open(r'nasdaqlisted.txt', 'r') as file:
        csvfile = csv.reader(file, delimiter='|')

        print('Column Names:')
        column_names = next(csvfile)
        print(column_names)

        print('Data:')
        for row in csvfile:
            print(row, end='')


# Call the main function.
main()
