print('starting...')

raise NameError('Whats up error')