# more python comments

print('Ricky Bobby') # name
print('3366  Speedway Blvd') # address
print('Talladega, AL 35160') # city, state, zipcode
