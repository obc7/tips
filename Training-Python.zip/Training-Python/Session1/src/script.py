'This is a literal string'
"This is another string"

"I'm a Python fanatic"         # this way is more readable

"""An even bigger
string that spans
three lines"""

'''An even bigger
string that spans
three lines'''

name = 'john hill'
print(name.title())

print(name.upper())
print(name.lower())

first_name = 'Bob'
last_name = 'George'
print(first_name + " " + last_name)

# age = 23
# message = "Happy " + age + "rd Birthday!"
#
# print(message)

age = 23
message = "Happy " + str(age) + "rd Birthday!"

print(message)

type(2)

s = 'Spam'
len(s)
s[0]
s[1]
s[-1]
s[-2]
s[1:3]
s[:3]
s[0:]
s[:]

2 + 3
3 - 2
2 * 3
3 / 2
2 + 3 * 4
(2 + 3) * 2

.1 + .1
2 * .2

' test' *  4


