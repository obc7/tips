print("Don't fear")
print("I'm  here!")

print('Your assignment ia to read "Hamlet" by tomorrow.')