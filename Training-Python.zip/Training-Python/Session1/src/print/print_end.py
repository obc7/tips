
print('Ricky Bobby')

print('3366 Speedway Blvd', end='  ')

print('Talladega, AL 35160')
