
print('Bears', 'Lions', 'Packers', 'Vikings', sep='*')

print('Bears', 'Lions', 'Packers', 'Vikings', sep='<--->')

print('Bears', 'Lions', 'Packers', 'Vikings')

