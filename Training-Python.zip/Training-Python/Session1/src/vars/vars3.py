age = 25
size = 12

print('I wear size', size)
