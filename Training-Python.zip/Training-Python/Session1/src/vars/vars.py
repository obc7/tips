age = 25
size = 12

print(age)
print(size)