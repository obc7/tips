
number = int(input('Enter your a number: '))


print('You enter a number', 'Great!' if number == 5 else 'Bad')

