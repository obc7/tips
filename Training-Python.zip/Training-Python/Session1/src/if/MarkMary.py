name1 = 'Mary'
name2 = 'Mark'

if name1 == name2:
  print('The names are the same')
else:
  print('The names are not the same')

