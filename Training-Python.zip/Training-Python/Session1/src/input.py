name = input('Enter your name: ')
age = int(input('Enter your age: '))
income = float(input('Enter your income: '))

print('Here is the data you entered')
print('Name:', name)
print('Age:', age)
print('Income:', income)