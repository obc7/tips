

class First:

    def __init__(self):
        print('First.__init__')


class Second:

    def __init__(self, value):
        print('Second.__init__')
        self.value = value


    def get_value(self):
        return self.value


first = First()
second = Second(100)

print()
print(first)

print()
print(second)
print(second.get_value())

