

def print_if_true(message, check):
    """
    Prints the first argument if a second argument is true.

    :param message: the item to print
    :param check: if true, print first argument
    :return:
    """
    if check:
        print(message)