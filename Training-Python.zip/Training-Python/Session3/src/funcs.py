
def do_nothing():
    pass


def make_a_sound():
    print('quack')


def times(x, y):
    return x * y


def many_return(x, y):
    return x + y, x * y, x / y


def intersect(seq1, seq2):
    res = []
    for x in seq1:
        if x in seq2:
            res.append(x)
    return res


make_a_sound()
print(many_return(2, 3))
print(times(3, 3))
print(intersect([1, 2,  3, 4], [4, 8, 7, 1]))
print(intersect([1, 2,  3, 4], (4, 8, 7, 1)))
print(intersect('SPAM', 'SCAM'))














