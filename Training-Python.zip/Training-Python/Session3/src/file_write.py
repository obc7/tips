

# This program writes three lines of data
# to a file.
def main():
    # Open a file named philosophers.txt.
    outfile = open('philosophers.txt', 'w')

    # Write the names of three philosphers
    # to the file.
    outfile.write('John Locke\n')
    outfile.write('David Hume\n')
    outfile.write('Edmund Burke\n')
    outfile.write('Friedeich Nietzsche\n')
    outfile.write('Plato\n')
    outfile.write('Socrates\n')
    outfile.write('Aristotle\n')
    outfile.write('Mazen Asfour\n')
    outfile.write('Sri Aurobindo\n')
    outfile.write('Avicenna\n')
    outfile.write('Karl Marx\n')
    outfile.write('Lao Tzu\n')

    # Close the file.
    outfile.close()

# Call the main function.
main()
