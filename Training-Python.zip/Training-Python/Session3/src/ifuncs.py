

def outer(a, b):
    def inner(c, d):
        return c + d
    return inner(a, b)


def outer2(saying):
    def inner():
        return 'What are you saying: %s' % saying
    return inner


print(outer(4, 7))

test_func = outer2('functions')
print(test_func())
