

class MyFirstClass:
    pass


def f():
    pass
